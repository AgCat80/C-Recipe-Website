/*
 * Author:  Gulian Ibrahim (refactored from original by Aydon Cupido, April 2023)
 * File:    MainPage.aspx.cs
 * Purpose: Main recipe dashboard. Users can add a recipe or view one by ID.
 *
 * Fixes:
 *  - userValidation() now checks that the query string 'name' param is present
 *    (original always returned true — validation was never enforced)
 *  - OnClick events must also be wired in the .aspx markup (see MainPage.aspx)
 */

using System;
using System.Web.UI;
using AdvancedCProject.ServiceReference1;

namespace AdvancedCProject
{
    public partial class WebForm5 : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack && !UserIsLoggedIn())
            {
                Response.Redirect("./Login.aspx");
            }
        }

        // Fixed: checks that a username was actually passed in the URL
        private bool UserIsLoggedIn()
        {
            return !string.IsNullOrEmpty(Request.QueryString["name"]);
        }

        protected void add_Click(object sender, EventArgs e)
        {
            if (!UserIsLoggedIn())
            {
                error.Text = "Session expired. Please log in again.";
                return;
            }

            string name = RecipeName.Value.Trim();
            string body = RecipeBody.Value.Trim();

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(body))
            {
                error.Text = "Please fill in both the recipe name and body.";
                return;
            }

            WebService1SoapClient web = new WebService1SoapClient();
            bool success = web.addRecipe(name, Request.QueryString["name"], body);

            error.Text = success
                ? "Recipe added successfully."
                : "Failed to add recipe. Please try again.";
        }

        protected void view_Click(object sender, EventArgs e)
        {
            string id = search.Value.Trim();

            if (string.IsNullOrEmpty(id))
            {
                error.Text = "Please enter a recipe ID to search.";
                return;
            }

            Response.Redirect("./Recipe.aspx?id=" + Server.UrlEncode(id));
        }
    }
}
