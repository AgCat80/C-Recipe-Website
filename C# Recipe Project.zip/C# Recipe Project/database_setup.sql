-- =============================================================
-- RecipeDB Setup Script
-- Author: Gulian Ibrahim
-- Database: SQL Server (migrate from original Microsoft Access .mdb)
-- Run this script in SSMS or Azure Data Studio against a new DB.
-- =============================================================

-- Create the database (run separately if needed)
-- CREATE DATABASE RecipeDB;
-- GO
-- USE RecipeDB;
-- GO

-- ── Users ──────────────────────────────────────────────────────
-- Stores registered user accounts.
-- NOTE: In production, password_ should be a salted hash (e.g. bcrypt).
--       Storing plaintext passwords is shown here for educational clarity only.
CREATE TABLE Users (
    userID    INT           IDENTITY(1,1) PRIMARY KEY,
    email     NVARCHAR(255) NOT NULL UNIQUE,
    username  NVARCHAR(100) NOT NULL UNIQUE,
    password_ NVARCHAR(255) NOT NULL,
    security_ NVARCHAR(255) NOT NULL   -- answer to security question
);
GO

-- ── Recipes ────────────────────────────────────────────────────
-- Stores recipes submitted by users.
CREATE TABLE Recipes (
    recipeID    INT           IDENTITY(1,1) PRIMARY KEY,
    recipeName  NVARCHAR(255) NOT NULL,
    recipeOwner NVARCHAR(100) NOT NULL,
    recipeBody  NVARCHAR(MAX) NOT NULL,
    createdAt   DATETIME      NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Recipes_Owner FOREIGN KEY (recipeOwner)
        REFERENCES Users(username) ON DELETE CASCADE
);
GO

-- ── RatingInformation ──────────────────────────────────────────
-- One rating row per recipe (average or latest rating).
CREATE TABLE RatingInformation (
    ratingID     INT IDENTITY(1,1) PRIMARY KEY,
    recipeID     INT NOT NULL,
    recipeRating INT NOT NULL CHECK (recipeRating BETWEEN 1 AND 5),
    CONSTRAINT FK_Rating_Recipe FOREIGN KEY (recipeID)
        REFERENCES Recipes(recipeID) ON DELETE CASCADE
);
GO

-- ── Sample Data ─────────────────────────────────────────────────
INSERT INTO Users (email, username, password_, security_)
VALUES ('demo@example.com', 'demo_user', 'demo1234', 'Malibu');
GO

INSERT INTO Recipes (recipeName, recipeOwner, recipeBody)
VALUES (
    'Simple Pasta',
    'demo_user',
    'Boil pasta. Fry garlic in olive oil. Toss pasta in oil. Add salt and pepper. Serve.'
);
GO

INSERT INTO RatingInformation (recipeID, recipeRating)
VALUES (1, 4);
GO

-- ── Useful queries for testing ──────────────────────────────────
-- SELECT * FROM Users;
-- SELECT * FROM Recipes;
-- SELECT * FROM RatingInformation;
