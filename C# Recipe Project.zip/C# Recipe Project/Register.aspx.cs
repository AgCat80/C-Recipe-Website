/*
 * Author:  Gulian Ibrahim (refactored from original by Aydon Cupido, April 2023)
 * File:    Register.aspx.cs
 * Purpose: Handles new user registration.
 *
 * Fixes:
 *  - Removed triple-duplicated using statements
 *  - & (bitwise AND) replaced with && (logical AND) for field validation
 *  - checkUserExistence now checks by username (consistent with the Users table query)
 *  - Input trimming added before DB calls
 */

using System;
using System.Web.UI;
using AdvancedCProject.ServiceReference1;

namespace AdvancedCProject
{
    public partial class WebForm1 : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            string email    = this.emailbox.Value.Trim();
            string username = this.usernamebox.Value.Trim();
            string password = this.Passwordbox.Value;
            string security = this.secquestionbox.Value.Trim();

            // Fixed: & → && so short-circuit evaluation works correctly
            if (string.IsNullOrEmpty(email) ||
                string.IsNullOrEmpty(username) ||
                string.IsNullOrEmpty(password) ||
                string.IsNullOrEmpty(security))
            {
                this.error.Text = "Please fill in all fields.";
                return;
            }

            WebService1SoapClient web = new WebService1SoapClient();

            if (web.checkUserExistence(username))
            {
                this.error.Text = "That username is already taken.";
            }
            else
            {
                web.addProfile(email, username, password, security);
                Response.Redirect("./Login.aspx");
            }
        }
    }
}
