/*
 * Author:  Gulian Ibrahim (refactored from original by Aydon Cupido, April 2023)
 * File:    WebService1.asmx.cs
 * Purpose: SOAP Web Service providing all database operations for the Recipe Web App.
 *
 * Changes from original:
 *  - Connection string now reads from Web.config via WebConfigurationManager (no hardcoded path)
 *  - All queries converted to parameterised OleDbCommand (eliminates SQL injection)
 *  - OleDbConnection managed with using() blocks (eliminates double-close, ensures disposal)
 *  - conn removed as instance field (eliminates thread-safety issue on WebService class)
 *  - addRecipe rewritten: fixed broken format string and wrong column mapping
 *  - rateRecipe fixed: second parameter was {0} instead of {1}
 *  - getRecipeBody fixed: was querying WHERE recipeBody= instead of WHERE recipeNum=
 *  - Unreachable return false after finally block removed
 *  - validateProfile now used correctly by Login (was previously calling wrong method)
 */

using System;
using System.Web.Services;
using System.Data.OleDb;
using System.Web.Configuration;

namespace AdvancedCProject
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class WebService1 : System.Web.Services.WebService
    {
        // ── Connection helper ────────────────────────────────────────────────
        // Reads the connection string from Web.config so no path is hardcoded.
        // Returns a new, open connection. Caller must dispose it (use 'using').
        private OleDbConnection GetOpenConnection()
        {
            string connectionString = WebConfigurationManager
                .ConnectionStrings["RecipeDBConnectionString"].ConnectionString;

            var conn = new OleDbConnection(connectionString);
            conn.Open();
            return conn;
        }


        // ── User operations ──────────────────────────────────────────────────

        /// <summary>
        /// Checks whether a username already exists in the Users table.
        /// </summary>
        [WebMethod]
        public bool checkUserExistence(string username)
        {
            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT COUNT(*) FROM Users WHERE username = ?";
                    cmd.Parameters.AddWithValue("@username", username);

                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (OleDbException)
            {
                return false;
            }
        }

        /// <summary>
        /// Registers a new user. Returns false if the insert fails.
        /// </summary>
        [WebMethod]
        public bool addProfile(string email, string username, string password, string securityAnswer)
        {
            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText =
                        "INSERT INTO Users (email, username, password_, security_) VALUES (?, ?, ?, ?)";
                    cmd.Parameters.AddWithValue("@email",    email);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@security", securityAnswer);

                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (OleDbException)
            {
                return false;
            }
        }

        /// <summary>
        /// Deletes a user account by username.
        /// </summary>
        [WebMethod]
        public bool removeProfile(string username)
        {
            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM Users WHERE username = ?";
                    cmd.Parameters.AddWithValue("@username", username);

                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (OleDbException)
            {
                return false;
            }
        }

        /// <summary>
        /// Validates a login attempt by matching username and password.
        /// Called by Login.aspx on login button click.
        /// </summary>
        [WebMethod]
        public bool validateProfile(string username, string password)
        {
            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText =
                        "SELECT COUNT(*) FROM Users WHERE username = ? AND password_ = ?";
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (OleDbException)
            {
                return false;
            }
        }

        /// <summary>
        /// Validates a user by email + security answer for the forgot-password flow.
        /// </summary>
        [WebMethod]
        public bool UserValidation(string email, string securityAnswer)
        {
            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText =
                        "SELECT COUNT(*) FROM Users WHERE email = ? AND security_ = ?";
                    cmd.Parameters.AddWithValue("@email",    email);
                    cmd.Parameters.AddWithValue("@security", securityAnswer);

                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (OleDbException)
            {
                return false;
            }
        }

        /// <summary>
        /// Resets a user's password after verifying their email and security answer.
        /// </summary>
        [WebMethod]
        public bool resetPassword(string email, string securityAnswer, string newPassword)
        {
            // Verify identity first before attempting the update
            if (!UserValidation(email, securityAnswer))
                return false;

            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText =
                        "UPDATE Users SET password_ = ? WHERE email = ?";
                    cmd.Parameters.AddWithValue("@password", newPassword);
                    cmd.Parameters.AddWithValue("@email",    email);

                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (OleDbException)
            {
                return false;
            }
        }


        // ── Recipe operations ────────────────────────────────────────────────

        /// <summary>
        /// Adds a new recipe. Fixed: original had a broken format string and
        /// inserted the auto-increment position value as the recipe name.
        /// </summary>
        [WebMethod]
        public bool addRecipe(string recipeName, string recipeOwner, string recipeBody)
        {
            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText =
                        "INSERT INTO Recipes (recipeName, recipeOwner, recipeBody) VALUES (?, ?, ?)";
                    cmd.Parameters.AddWithValue("@recipeName",  recipeName);
                    cmd.Parameters.AddWithValue("@recipeOwner", recipeOwner);
                    cmd.Parameters.AddWithValue("@recipeBody",  recipeBody);

                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (OleDbException)
            {
                return false;
            }
        }

        /// <summary>
        /// Deletes a recipe by name and owner.
        /// </summary>
        [WebMethod]
        public bool removeRecipe(string recipeName, string recipeOwner)
        {
            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText =
                        "DELETE FROM Recipes WHERE recipeName = ? AND recipeOwner = ?";
                    cmd.Parameters.AddWithValue("@recipeName",  recipeName);
                    cmd.Parameters.AddWithValue("@recipeOwner", recipeOwner);

                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (OleDbException)
            {
                return false;
            }
        }

        /// <summary>
        /// Returns the name of a recipe by its ID.
        /// </summary>
        [WebMethod]
        public string getRecipeName(string recipeNum)
        {
            if (!int.TryParse(recipeNum, out int id))
                return string.Empty;

            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT recipeName FROM Recipes WHERE recipeID = ?";
                    cmd.Parameters.AddWithValue("@recipeID", id);

                    object result = cmd.ExecuteScalar();
                    return result != null ? result.ToString() : string.Empty;
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Returns the body of a recipe by its ID.
        /// Fixed: original queried WHERE recipeBody = recipeNum which is meaningless.
        /// </summary>
        [WebMethod]
        public string getRecipeBody(string recipeNum)
        {
            if (!int.TryParse(recipeNum, out int id))
                return string.Empty;

            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT recipeBody FROM Recipes WHERE recipeID = ?";
                    cmd.Parameters.AddWithValue("@recipeID", id);

                    object result = cmd.ExecuteScalar();
                    return result != null ? result.ToString() : string.Empty;
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Rates a recipe. Fixed: original used {0} for both parameters (both became 'value').
        /// </summary>
        [WebMethod]
        public bool rateRecipe(string recipeNum, int value)
        {
            if (!int.TryParse(recipeNum, out int id))
                return false;

            try
            {
                using (OleDbConnection conn = GetOpenConnection())
                using (OleDbCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText =
                        "UPDATE RatingInformation SET recipeRating = ? WHERE recipeID = ?";
                    cmd.Parameters.AddWithValue("@rating",   value);
                    cmd.Parameters.AddWithValue("@recipeID", id);

                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (OleDbException)
            {
                return false;
            }
        }
    }
}
