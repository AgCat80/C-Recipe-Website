/*
 * Author:  Gulian Ibrahim (refactored from original by Aydon Cupido, April 2023)
 * File:    Recipe.aspx.cs
 * Purpose: Displays a recipe by ID and allows a 1–5 rating to be submitted.
 *
 * Fixes:
 *  - Added guard for missing 'id' query string parameter
 *  - Added validation to ensure rating input is a number between 1 and 5
 */

using System;
using System.Web.UI;
using AdvancedCProject.ServiceReference1;

namespace AdvancedCProject
{
    public partial class WebForm4 : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string id = Request.QueryString["id"];

            if (string.IsNullOrEmpty(id))
            {
                recipetitle.Text = "No recipe ID provided.";
                recipebody.Text  = string.Empty;
                return;
            }

            WebService1SoapClient web = new WebService1SoapClient();
            recipetitle.Text = web.getRecipeName(id);
            recipebody.Text  = web.getRecipeBody(id);
        }

        protected void rate_Click(object sender, EventArgs e)
        {
            string id = Request.QueryString["id"];

            if (string.IsNullOrEmpty(id))
            {
                return;
            }

            if (!int.TryParse(ratingbox.Text, out int rating) || rating < 1 || rating > 5)
            {
                // Optionally surface an error label here
                return;
            }

            WebService1SoapClient web = new WebService1SoapClient();
            web.rateRecipe(id, rating);
        }
    }
}
