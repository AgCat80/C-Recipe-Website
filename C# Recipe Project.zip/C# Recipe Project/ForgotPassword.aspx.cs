/*
 * Author:  Gulian Ibrahim (refactored from original by Aydon Cupido, April 2023)
 * File:    ForgotPassword.aspx.cs
 * Purpose: Allows a user to reset their password using their email and security answer.
 *
 * Fixes:
 *  - newpassword.Text → newpasswordbox.Text
 *    (newpassword is a Label ID, not a TextBox; caused a compile error)
 *  - validateProfile(email, security) → UserValidation(email, security)
 *    (validateProfile checks username+password, not email+security)
 */

using System;
using System.Web.UI;
using AdvancedCProject.ServiceReference1;

namespace AdvancedCProject
{
    public partial class WebForm3 : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void changepassword_Click(object sender, EventArgs e)
        {
            string email       = emailbox.Text.Trim();
            string security    = secquestionbox.Text.Trim();
            string newPwd      = newpasswordbox.Text;       // Fixed: was newpassword.Text
            string repeatPwd   = repeatpasswordbox.Text;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(security) ||
                string.IsNullOrEmpty(newPwd) || string.IsNullOrEmpty(repeatPwd))
            {
                error.Text = "Please fill in all fields.";
                return;
            }

            if (newPwd != repeatPwd)
            {
                error.Text = "The passwords you entered do not match.";
                return;
            }

            WebService1SoapClient web = new WebService1SoapClient();

            // Fixed: was calling validateProfile(email, security) which checks username+password
            // UserValidation is the correct method for email + security answer
            if (web.UserValidation(email, security))
            {
                web.resetPassword(email, security, newPwd);
                Response.Redirect("./Login.aspx");
            }
            else
            {
                error.Text = "Email or security answer is incorrect.";
            }
        }
    }
}
