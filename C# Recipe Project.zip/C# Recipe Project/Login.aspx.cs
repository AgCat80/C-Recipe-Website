/*
 * Author:  Gulian Ibrahim (refactored from original by Aydon Cupido, April 2023)
 * File:    Login.aspx.cs
 * Purpose: Handles user login. Redirects to MainPage on success.
 *
 * Fix: original called UserValidation(username, password) which is the email+security
 *      method used for password reset. Corrected to validateProfile(username, password).
 */

using System;
using System.Web.UI;
using AdvancedCProject.ServiceReference1;

namespace AdvancedCProject
{
    public partial class WebForm2 : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Login_Click(object sender, EventArgs e)
        {
            string username = this.usernamebox.Value.Trim();
            string password = this.passwordbox.Value;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                this.error.Text = "Please provide a username and password.";
                return;
            }

            WebService1SoapClient web = new WebService1SoapClient();

            // Fixed: was calling UserValidation (email+security) instead of validateProfile
            if (web.validateProfile(username, password))
            {
                Response.Redirect("./MainPage.aspx?name=" + Server.UrlEncode(username));
            }
            else
            {
                this.error.Text = "Incorrect username or password.";
            }
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            Response.Redirect("./Register.aspx");
        }

        protected void ForgotPassword_Click(object sender, EventArgs e)
        {
            Response.Redirect("./ForgotPassword.aspx");
        }
    }
}
